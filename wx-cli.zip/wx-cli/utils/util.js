

function getHistoryList() {
}

module.exports = {
  formatTime: getHistoryList
}

